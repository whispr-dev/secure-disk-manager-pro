use crate::error::{Result, SdmError};
use std::fs;
use std::path::Path;

fn hex_encode(data: &[u8]) -> String {
    let mut out = String::with_capacity(data.len() * 2);
    for byte in data {
        out.push_str(&format!("{byte:02X}"));
    }
    out
}

fn hex_decode(hex: &str) -> Result<Vec<u8>> {
    let clean: String = hex.chars().filter(|c| !c.is_whitespace()).collect();
    if clean.len() % 2 != 0 {
        return Err(SdmError::InvalidFormat("hex string has odd length".to_string()));
    }
    let mut out = Vec::with_capacity(clean.len() / 2);
    for pair in clean.as_bytes().chunks(2) {
        let s = std::str::from_utf8(pair).map_err(|e| SdmError::InvalidFormat(e.to_string()))?;
        out.push(u8::from_str_radix(s, 16).map_err(|e| SdmError::InvalidFormat(e.to_string()))?);
    }
    Ok(out)
}

fn extract_ss(xml: &str) -> Result<String> {
    let start_tag = "<SS>";
    let end_tag = "</SS>";
    let start = xml.find(start_tag).ok_or_else(|| SdmError::InvalidFormat("missing <SS>".to_string()))? + start_tag.len();
    let end = xml[start..].find(end_tag).ok_or_else(|| SdmError::InvalidFormat("missing </SS>".to_string()))? + start;
    Ok(xml[start..end].trim().to_string())
}

/// C++ equivalent: `DPAPIEncryptor::encrypt_to_xml`.
pub fn encrypt_to_xml(plaintext: &str, out_path: impl AsRef<Path>) -> Result<()> {
    let protected = dpapi_protect(plaintext.as_bytes())?;
    let xml = format!("<Objs><SS>{}</SS></Objs>\n", hex_encode(&protected));
    fs::write(out_path, xml)?;
    Ok(())
}

/// C++ equivalent: `DPAPIDecryptor::decrypt_from_xml`.
pub fn decrypt_from_xml(xml_path: impl AsRef<Path>) -> Result<String> {
    let xml = fs::read_to_string(xml_path)?;
    let hex = extract_ss(&xml)?;
    let protected = hex_decode(&hex)?;
    let plain = dpapi_unprotect(&protected)?;
    String::from_utf8(plain).map_err(|e| SdmError::Crypto(e.to_string()))
}

#[cfg(windows)]
fn dpapi_protect(data: &[u8]) -> Result<Vec<u8>> {
    use std::ptr::{null, null_mut};
    use windows_sys::Win32::Security::Cryptography::{CryptProtectData, DATA_BLOB};
    use windows_sys::Win32::System::Memory::LocalFree;

    let mut input = DATA_BLOB { cbData: data.len() as u32, pbData: data.as_ptr() as *mut u8 };
    let mut output = DATA_BLOB { cbData: 0, pbData: null_mut() };
    let ok = unsafe { CryptProtectData(&mut input, null(), null_mut(), null_mut(), null_mut(), 0, &mut output) };
    if ok == 0 {
        return Err(SdmError::Crypto("CryptProtectData failed".to_string()));
    }
    let protected = unsafe { std::slice::from_raw_parts(output.pbData, output.cbData as usize).to_vec() };
    unsafe { let _ = LocalFree(output.pbData as _); }
    Ok(protected)
}

#[cfg(windows)]
fn dpapi_unprotect(data: &[u8]) -> Result<Vec<u8>> {
    use std::ptr::{null_mut};
    use windows_sys::Win32::Security::Cryptography::{CryptUnprotectData, DATA_BLOB};
    use windows_sys::Win32::System::Memory::LocalFree;

    let mut input = DATA_BLOB { cbData: data.len() as u32, pbData: data.as_ptr() as *mut u8 };
    let mut output = DATA_BLOB { cbData: 0, pbData: null_mut() };
    let ok = unsafe { CryptUnprotectData(&mut input, null_mut(), null_mut(), null_mut(), null_mut(), 0, &mut output) };
    if ok == 0 {
        return Err(SdmError::Crypto("CryptUnprotectData failed".to_string()));
    }
    let plain = unsafe { std::slice::from_raw_parts(output.pbData, output.cbData as usize).to_vec() };
    unsafe { let _ = LocalFree(output.pbData as _); }
    Ok(plain)
}

#[cfg(not(windows))]
fn dpapi_protect(_data: &[u8]) -> Result<Vec<u8>> {
    Err(SdmError::UnsupportedPlatform("Windows DPAPI is only available on Windows"))
}

#[cfg(not(windows))]
fn dpapi_unprotect(_data: &[u8]) -> Result<Vec<u8>> {
    Err(SdmError::UnsupportedPlatform("Windows DPAPI is only available on Windows"))
}

/// C++ equivalent: `GhostScriptVault::decrypt_script`.
pub fn decrypt_script(xml_path: impl AsRef<Path>) -> Result<String> {
    decrypt_from_xml(xml_path)
}

/// C++ equivalent name: `GhostScriptVault::execute_decrypted_script`.
///
/// Deliberately blocked: hidden PowerShell execution from decrypted blobs was
/// not ported.
pub fn execute_decrypted_script(_script_contents: &str) -> Result<()> {
    Err(SdmError::Blocked("decrypted script execution was not ported"))
}
